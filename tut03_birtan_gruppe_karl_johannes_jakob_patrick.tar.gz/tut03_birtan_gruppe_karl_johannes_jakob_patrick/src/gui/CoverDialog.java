package gui;

import javax.swing.JFrame;

public class CoverDialog extends JFrame
{
	
	public CoverDialog(){
		setTitle("Change Cover");
		setSize(200,100);
	}
  // this should bring up the dialog for changing/removing the cover art
}
